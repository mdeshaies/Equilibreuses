#ifndef CONSTANTES_H
#define CONSTANTES_H

#define NB_ECHANTILLONS_PAR_CANAL 2000
#define NB_CANAUX 2

#define CH0 0
#define CH1 1

#endif // CONSTANTES_H
